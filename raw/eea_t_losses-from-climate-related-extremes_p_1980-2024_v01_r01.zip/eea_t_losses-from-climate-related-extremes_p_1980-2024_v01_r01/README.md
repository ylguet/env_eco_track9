# Economic losses from climate-related extremes in Europe (1980-2024), Oct. 2025 revision 1

This metadata considers the 2024 data including the year 2010 Euro equivalent values as a baseline on total and insured economic losses and the number of fatalities from weather- and climate-related events in EU Member States and EEA member countries since 1980. Weather- and climate-related hazards considered are those types classified as meteorological hazards (e.g. storms), hydrological hazards (e.g. floods) and climatological hazards (e.g. heatwaves) based on the classification by the International Council for Science (ICSU). The geophysical hazards (e.g. earthquakes and volcanoes) are included for comparison purposes. An event can occur in several countries, but the information is split per country.

The data is based on the RiskLayer CATDAT datasets (received under institutional agreement), and on the Eurostat collection of economic indicators, whereas data from earlier years not covered by Eurostat have been completed using data from the Annual Macro-Economic Database of the European Commission (AMECO), the International Monetary Fund’s (IMF) World Economic Outlook (WEO), the Total Economy Database (TED) and the World Bank database. The average population of a country over the period of the time series is used.

The data contains details related to EEA’s indicator “Economic losses from climate-related events in Europe” (https://www.eea.europa.eu/ims/economic-losses-from-climate-related), updated annually. Additional detail on the data and the indicator can be found in the EEA briefing "Economic losses and fatalities from weather- and climate-related events in Europe", 2024 (https://www.eea.europa.eu/en/analysis/publications/economic-losses-from-climate-extremes).

This revised version includes fixes for redundant data.

*) This designation is without prejudice to positions on status, and is in line with UNSC 1244 and the ICJ Opinion on the Kosovo Declaration of Independence.https://sdi.eea.europa.eu/catalogue/srv/api/records/569291df-7bec-44cc-b829-285671f5f238


[More information](https://sdi.eea.europa.eu/catalogue/srv/api/records/569291df-7bec-44cc-b829-285671f5f238)
    